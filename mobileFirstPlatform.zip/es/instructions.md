Abrir Guía de Iniciación
-----------------------------------------
¡Enhorabuena por su nuevo Backend móvil!

Para utilizar la plantilla Backend móvil como punto de partida, y si ya tiene una configuración de entorno de desarrollo, empiece con estos pasos sencillos:

1. [Descargar paquete de aplicación de inicio](${ace-url}/rest/apps/${app-guid}/starter-download)
2. Descargar [SDKs](${doc-url}/#starters/mobile/sdk.html)
3. Modificar el paquete de aplicación de inicio según sea necesario
4. Utilizar la [interfaz de línea de mandatos cf](https://github.com/cloudfoundry/cli) para rechazar su aplicación actualizada
