Mise en route
-----------------------------------------
Bienvenue dans votre nouvel arrière-plan mobile

Pour utiliser le modèle d'arrière-plan mobile en tant que point de départ, si vous avez déjà configuré un environnement de développement, procédez comme suit :

1. [téléchargez le package d'applications de démarrage](${ace-url}/rest/apps/${app-guid}/starter-download)
2. Téléchargez les [kits de développement de logiciel](${doc-url}/#starters/mobile/sdk.html)
3. Modifiez le package d'applications de démarrage, en cas de besoin
4. via l'[interface de ligne de commande](https://github.com/cloudfoundry/cli) pour repousser la mise à jour de l'application
