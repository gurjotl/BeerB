Einführung öffnen
------------------
Herzlichen Glückwunsch zu Ihrem neuen mobilen Back-End!

Wenn Sie die Schablone "Mobiles Back-End" als Ausgangspunkt verwenden möchten und bereits eine Entwicklungsumgebung eingerichtet haben, starten Sie mit den folgenden einfachen Schritten:

1. [Starter-Anwendungspaket herunterladen](${ace-url}/rest/apps/${app-guid}/starter-download)
2. [SDKs](${doc-url}/#starters/mobile/sdk.html) herunterladen
3. Starter-Anwendungspaket ggf. modifizieren
4. Aktualisierte Anwendung über die [cf-Befehlszeilenschnittstelle](https://github.com/cloudfoundry/cli) mit Push zurückstellen
